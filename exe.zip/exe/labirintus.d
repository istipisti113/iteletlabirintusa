/home/istipisti113/program/rust/iteletlabirintusa/target/x86_64-pc-windows-gnu/debug/labirintus.exe: /home/istipisti113/program/rust/iteletlabirintusa/src/main.rs
